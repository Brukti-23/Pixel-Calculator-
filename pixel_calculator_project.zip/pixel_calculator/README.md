# Pixel Calculator ✳

A small, responsive calculator built with HTML, CSS, and vanilla JavaScript.

## Features
- Addition, subtraction, multiplication, and division
- Percent and positive/negative toggle
- Decimal input and clear button
- Keyboard support
- Responsive layout and custom gradient design
- Handles division by zero

## Run locally
1. Download or clone this repository.
2. Open `index.html` in your browser.

## Keyboard shortcuts
- `0–9`: enter numbers
- `+`, `-`, `*`, `/`: choose an operation
- `Enter` or `=`: calculate
- `.`: decimal point
- `Escape` or `Delete`: clear

Built as a beginner-friendly front-end project with HTML, CSS, and JavaScript.
