const display = document.querySelector("#display");
const expression = document.querySelector("#expression");
const statusText = document.querySelector("#status");
const keypad = document.querySelector("#keypad");

let currentValue = "0";
let storedValue = null;
let operator = null;
let waitingForNext = false;
let lastExpression = "";

function updateDisplay() {
  display.textContent = formatNumber(currentValue);
}

function formatNumber(value) {
  if (value === "Error") return value;
  const number = Number(value);
  if (!Number.isFinite(number)) return "Error";
  if (value.endsWith(".") || value === "-0") return value;
  return number.toLocaleString("en-US", {
    maximumFractionDigits: 8,
    useGrouping: true
  });
}

function setStatus(message) {
  statusText.textContent = message;
}

function inputNumber(number) {
  if (currentValue === "Error" || waitingForNext) {
    currentValue = number;
    waitingForNext = false;
  } else {
    currentValue = currentValue === "0" ? number : currentValue + number;
  }
  setStatus("READY WHEN YOU ARE");
  updateDisplay();
}

function inputDecimal() {
  if (currentValue === "Error" || waitingForNext) {
    currentValue = "0.";
    waitingForNext = false;
  } else if (!currentValue.includes(".")) {
    currentValue += ".";
  }
  updateDisplay();
}

function chooseOperator(nextOperator) {
  const inputValue = Number(currentValue);
  if (!Number.isFinite(inputValue)) return;

  if (operator && !waitingForNext) calculate();
  storedValue = Number(currentValue);
  operator = nextOperator;
  waitingForNext = true;
  expression.textContent = `${formatNumber(String(storedValue))} ${operator}`;
  setStatus("OPERATOR SELECTED");
}

function calculate() {
  if (operator === null || storedValue === null) return;

  const first = storedValue;
  const second = Number(currentValue);
  let result;

  switch (operator) {
    case "+": result = first + second; break;
    case "−": result = first - second; break;
    case "×": result = first * second; break;
    case "÷":
      if (second === 0) {
        currentValue = "Error";
        expression.textContent = "Cannot divide by zero";
        setStatus("TRY ANOTHER SUM");
        storedValue = null;
        operator = null;
        waitingForNext = true;
        updateDisplay();
        return;
      }
      result = first / second;
      break;
    default: return;
  }

  result = Number(result.toPrecision(10));
  lastExpression = `${formatNumber(String(first))} ${operator} ${formatNumber(String(second))} =`;
  expression.textContent = lastExpression;
  currentValue = String(result);
  storedValue = null;
  operator = null;
  waitingForNext = true;
  setStatus("CALCULATION COMPLETE ✦");
  updateDisplay();
}

function clearAll() {
  currentValue = "0";
  storedValue = null;
  operator = null;
  waitingForNext = false;
  lastExpression = "";
  expression.textContent = "\u00a0";
  setStatus("READY WHEN YOU ARE");
  updateDisplay();
}

function toggleSign() {
  if (currentValue === "0" || currentValue === "Error") return;
  currentValue = String(Number(currentValue) * -1);
  updateDisplay();
}

function percent() {
  if (currentValue === "Error") return;
  currentValue = String(Number(currentValue) / 100);
  updateDisplay();
}

keypad.addEventListener("click", (event) => {
  const button = event.target.closest("button");
  if (!button) return;

  if (button.dataset.number !== undefined) inputNumber(button.dataset.number);
  else if (button.dataset.operator) chooseOperator(button.dataset.operator);
  else {
    switch (button.dataset.action) {
      case "clear": clearAll(); break;
      case "decimal": inputDecimal(); break;
      case "equals": calculate(); break;
      case "sign": toggleSign(); break;
      case "percent": percent(); break;
    }
  }
});

document.addEventListener("keydown", (event) => {
  if (/^[0-9]$/.test(event.key)) inputNumber(event.key);
  else if (event.key === ".") inputDecimal();
  else if (event.key === "+") chooseOperator("+");
  else if (event.key === "-") chooseOperator("−");
  else if (event.key === "*") chooseOperator("×");
  else if (event.key === "/") {
    event.preventDefault();
    chooseOperator("÷");
  } else if (event.key === "Enter" || event.key === "=") calculate();
  else if (event.key === "Escape" || event.key === "Delete") clearAll();
  else if (event.key === "%") percent();
});

updateDisplay();
